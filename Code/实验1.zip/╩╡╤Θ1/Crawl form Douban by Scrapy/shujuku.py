import pymysql
DBHOST = 'PC015'
DBUSER = 'root'
DBPASS = '123456'
DBNAME = 'Douban'   #数据库名字
def jianbiao():
    try:
        db = pymysql.connect(host="localhost", user="root", password="123456", database="Douban")
        cur = db.cursor()   #声明游标
        cur.execute("DROP TABLE IF EXISTS doubanmovie")   #创建数据表 名为比赛 若存在则删除
        sql = 'CREATE TABLE doubanmovie(序号 INT(4) ,电影名 CHAR(20) NOT NULL ,导演 VARCHAR(30) ,\
              编剧 VARCHAR(100) ,主演 VARCHAR(200) ,类型 CHAR(14) ,制作国家 CHAR(20) ,语言 CHAR(10) ,上映日期 VARCHAR(20) ,\
              片长 VARCHAR(20), 又名 VARCHAR(30), 豆瓣评分 VARCHAR(5), 剧情简介 VARCHAR(230) )'
        cur.execute(sql)
        print("数据表创建成功！")
    except pymysql.Error as e:
        print("数据表创建失败！"+str(e))
jianbiao()