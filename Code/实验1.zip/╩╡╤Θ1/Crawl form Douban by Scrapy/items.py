# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DoubanItem(scrapy.Item):
    # define the fields for your item here like:
    上映时间 = scrapy.Field()
    电影名 = scrapy.Field()
    导演 = scrapy.Field()
    短评 = scrapy.Field()
    序号 = scrapy.Field()
    豆瓣评分 = scrapy.Field()
    别名 = scrapy.Field()
    国家 = scrapy.Field()
    #网页链接 = scrapy.Field()
    简介 = scrapy.Field()
    片长 = scrapy.Field()
    pass
