import time
import requests
from requests.exceptions import RequestException
import re          #正则表达式
import xlrd
import openpyxl
global k
import pymysql
k = 1 #设置全局变量以控制xlsx文件行写入
# 存为xlsx文件
workbook2 = openpyxl.Workbook()  # 创建一个Workbook对象
worksheet = workbook2.active
worksheet.title = "mysheet"  # excel下面的名字
Project = ['序号', '电影名', '导演', '编剧', '演员', '类型', '地区', '语言', '时长', '上映时间', '别名', '评分', '简介']
for j in range(len(Project)):
    worksheet.cell(1, j + 1, Project[j])
#workbook2.save(filename='dbmovie.xlsx')
def get_page(url):
    try:                                                           #防止网页反爬虫
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:    #表示网页服务器HTTP响应状态的3位数字代码
            response.encoding = 'utf-8'
            return response.text
        return None
    except RequestException:
        return None

def get_movie_list(html):                          #.*? 表示匹配任意数量的重复，但是在能使整个匹配成功的前提下使用最少的重复。
    pattern = re.compile('<div class="pic".*?em class="">(.*?)</em>.*?<a href="(.*?)">.*?</a>', re.S) #(.*?)是要提取的内容
    movie_list = pattern.findall(html)
    #print(movie_list[0])
    #print(movie_list)
    #已获取得序号
    return movie_list


def get_content(movie_url):
    global k
    global workbook2
    global worksheet
    #re.compile()用于编译正则表达式
    html = get_page(movie_url)
    html = str(html)
    # 获取片名
    pattern = re.compile('<span property="v:itemreviewed">(.*?)</span>', re.S)
    name = pattern.findall(html)
    print(name)

    # 导演
    pattern = re.compile('<a.*?rel="v:directedBy">(.*?)</a>', re.S)
    director = pattern.findall(html)
    print(director)

    # 编剧 没办法一次解析出来 可以解析两次 第一次缩小范围,只有标签以外的文本被解析出来
    pattern = re.compile("<span ><span class='pl'>编剧</span>: <span class='attrs'>(.*?)</span></span><br/>", re.S)
    author = pattern.findall(html)
    if author:
        pattern = re.compile('<a href=.*?>(.*?)</a>', re.S)
        author = pattern.findall(author[0])
    print(author)

    # 主演
    pattern = re.compile('<a.*?rel="v:starring">(.*?)</a>', re.S)
    actor = pattern.findall(html)
    print(actor)

    # 类型
    pattern = re.compile('<span property="v:genre">(.*?)</span>', re.S)
    type = pattern.findall(html)
    print(type)

    # 制片国家/地区
    pattern = re.compile('<span class="pl">制片国家/地区:</span>(.*?)<br/>', re.S)
    area = pattern.findall(html)
    print(area)

    # 语言
    pattern = re.compile('<span class="pl">语言:</span>(.*?)<br/>', re.S)
    language = pattern.findall(html)
    print(language)

    # 上映时间
    pattern = re.compile('<span property="v:initialReleaseDate" content=.*?>(.*?)</span>', re.S)
    time = pattern.findall(html)
    print(time)

    # 片长
    pattern = re.compile('<span property="v:runtime" content=.*?>(.*?)</span>', re.S)
    runtime = pattern.findall(html)
    print(runtime)

    # 又名
    pattern = re.compile('<span class="pl">又名:</span>(.*?)<br/>', re.S)
    other_name = pattern.findall(html)
    print(other_name)

    # 评分
    pattern = re.compile('<strong class="ll rating_num" property="v:average">(.*?)</strong>', re.S)
    score = pattern.findall(html)
    print(score)

    # 简介  1120行  strip()用于清除空格，是用于字符串的方法，89行没有【0】不是字符串会报措
    pattern = re.compile('<span property="v:summary".*?>(.*?)</span>', re.S)
    #pattern = re.compile('<span class="all hidden">(.*?)</span>', re.S)  有的电影简介不需要拉开即可完整显示，故没有all hidden类的标签
    introduce = pattern.findall(html)
    introduce = introduce[0].strip().replace('\n', '').replace('\t', '').replace('<br />', '').replace(' ', '')
    print(introduce)

    # 保存数据  movie[1]是网址
    with open('result.txt', 'a', encoding='utf-8') as f:
        f.write(movie[0] + '\t' + str(name) + '\t' + str(director) + '\t' + str(author) + '\t' + str(
            actor) + '\t' + str(type) + '\t' + str(area) + '\t' + str(language) + '\t' + str(time) + '\t' +
                str(runtime) + '\t' + str(other_name) + '\t' + str(score) + '\t' + introduce + '\n')

    name_ = str(name).strip('[').strip(']').replace('\'', '')
    author_ = str(director).strip('[').strip(']').replace('\'', '')
    director_ = str(author).strip('[').strip(']').replace('\'', '')
    actor_ = str(actor).strip('[').strip(']').replace('\'', '')
    type_ = str(type).strip('[').strip(']').replace('\'', '')
    area_ = str(area).strip('[').strip(']').replace('\'', '')
    language_ = str(language).strip('[').strip(']').replace('\'', '')
    time_ = str(time).strip('[').strip(']').replace('\'', '')
    runtime_ = str(runtime).strip('[').strip(']').replace('\'', '')
    othername = str(other_name).strip('[').strip(']').replace('\'', '')
    score_ = str(score).strip('[').strip(']').replace('\'', '')
    k += 1  # print("k值为", k)
    if(k<252):
        worksheet.cell(k, 1, movie[0])
        worksheet.cell(k, 2, name_)
        worksheet.cell(k, 3, director_)
        worksheet.cell(k, 4, author_)
        worksheet.cell(k, 5, actor_)
        worksheet.cell(k, 6, type_)
        worksheet.cell(k, 7, area_)
        worksheet.cell(k, 8, language_)
        worksheet.cell(k, 9, time_)
        worksheet.cell(k, 10, runtime_)
        worksheet.cell(k, 11, othername)
        worksheet.cell(k, 12, score_)
        worksheet.cell(k, 13, introduce)
        workbook2.save(filename='dbmovie.xlsx')
    if(k==251):
        workbook2.close()

'''
    try:
        db = pymysql.connect(host="localhost", user="root", password="123456", database="Douban")
        cur = db.cursor()  # 声明游标
        data = (movie[0], name_, author_, director_, actor_, type_, area_, language_, time_, runtime_,
                othername, score_, introduce)
        sql = 'INSERT INTO doubanmovie(序号,电影名,导演,编剧,主演,类型,制作国家,语言,上映日期,片长,又名,豆瓣评分,剧情简介) \
              VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'            # 表名  字段名 插入的值
        cur.execute(sql, data)  # 将数据进行提交
        db.commit()  # 数据库的提交
        print("数据插入成功!")
    except pymysql.Error as e:
        print("数据插入失败"+str(e))
        db.rollback()   #数据插入失败返回原先状态
'''
if __name__ == '__main__':
    for i in range(10): #网页按数学上的规律找顺序
        url = 'https://movie.douban.com/top250?start=' + str(i * 25)   #print(url)
        # 发送请求 获取响应
        html = get_page(url)                      # print(html) # 解析响应 获取电影列表
        movie_list = get_movie_list(html)         # print(movie_list)
        for movie in movie_list:                  # 获取每部电影的详细内容
            get_content(movie[1])                 #movie[1]是movie数组里面第二个元素，即每一步电影的二级页面网址。
            time.sleep(2)
