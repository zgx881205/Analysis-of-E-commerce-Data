#!/usr/bin/env python
# coding: utf-8

# In[1]:


#  链家爬虫
from lxml import etree
import csv
import requests
from tqdm import tqdm  # 爬取进度条显示模块

print('信息爬取中:\n')


class HouseParse(object):
    # 初始化
    def __init__(self):
        # 请求头
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.55 Safari/537.36 Edg/96.0.1054.43'
        }
        # 列表存放数据
        self.data_list = []

    def Sponsor(self):
        # 翻页数据
        for i in tqdm(range(1, 101)):
            url = f'https://changzhou.lianjia.com/ershoufang/rs{i}/'
            response = requests.get(url=url, headers=self.headers)

            html = etree.HTML(response.content.decode('utf-8'))
            #找到内容所在的li标签下
            elements = html.xpath('//div/ul[@class="sellListContent"]/li')
            # print(elements)
            for element in elements:
                #创建字典
                dict_ = {}
                #标题
                dict_['title'] = element.xpath('./div[1]/div[1]/a/text()')[0]
                #地址
                dict_['flood'] = ''.join([i.strip() for i in element.xpath('./div[1]/div[@class="flood"]//text()')])
                #简介
                dict_['introduction'] = element.xpath('./div[1]/div[@class="address"]/div/text()')[0]

                #总价
                dict_['total_price'] = ''.join([i.strip() for i in element.xpath('.//div[@class="totalPrice totalPrice2"]/span/text()')])
                #单价
                dict_['unit_price'] = ''.join([i.strip() for i in element.xpath('.//div[@class="unitPrice"]/span/text()')])
                # print(dict_)
                self.data_list.append(dict_)

                ''' L = dict_['introduction'][0].split('|')
                dict_['model'] = L[0].strip()
                dict_['area'] = L[1].strip()
                dict_['direction'] = L[2].strip()
                dict_['perfect'] = L[3].strip()
                dict_['floor'] = L[4].strip()'''


    def save_data(self):
        #保存数据
        with open('lianjia.csv', 'w', encoding='utf-8', newline='')as f:
            writer = csv.DictWriter(f, fieldnames=['title', 'flood', 'introduction','total_price','unit_price'])
            writer.writeheader()
            writer.writerows(self.data_list)

    def main(self):
        self.Sponsor()
        self.save_data()

if __name__ == '__main__':
    house = HouseParse()
    house.main()

print('\n爬取成功！')


# In[1]:


#  导入lianjia.csv
import pandas as pd
colname=['标题','地段','简要信息','总价（万元）','单位价格（元/㎡）']
data = pd.read_csv( 'lianjia.csv',names=colname)
print(data)


# In[2]:


houselist=data.drop([0],axis=0)# 第0行为原标题，在此处应去除
print(houselist)


# In[3]:


houselist=houselist.drop([255],axis=0)  
houselist=houselist.drop([309],axis=0) 
houselist=houselist.drop([310],axis=0) 
houselist=houselist.drop([334],axis=0) # 第256、310、311、335行数据为车位出售
houselist=houselist.drop([141],axis=0)
houselist=houselist.drop([143],axis=0)
houselist=houselist.drop([327],axis=0)
houselist=houselist.drop([655],axis=0) # 第142、144、328、656行数据为异常值
houselist=houselist.drop('标题',axis=1)
print(houselist)


# In[6]:


#  对‘简要信息’进行处理
house_info=houselist['简要信息'].str.split('|', expand=True)
house_info


# In[5]:


house_info.name=['户型','面积（㎡）','朝向','装修情况','楼层','结构']
house_info.columns=house_info.name
print(house_info)


# In[7]:


house_info['室数'] = house_info['户型'].str[0]
house_info['厅数'] = house_info['户型'].str[2]


# In[7]:


print(house_info)


# In[8]:


house=houselist.join(house_info)
house=house.drop('简要信息',axis=1)
print(house)


# In[9]:


print(house.dtypes)  # 数据类型


# In[10]:


#  部分数据类型转换以及部分数据处理
house['总价（万元）']=house['总价（万元）'].astype(float)
house['单位价格（元/㎡）'] = house['单位价格（元/㎡）'].str[:-3]
house['单位价格（元/㎡）'] = house['单位价格（元/㎡）'].str.replace(',', '').astype(float)
house['面积（㎡）'] = house['面积（㎡）'].str[:-3]
house['面积（㎡）'] = house['面积（㎡）'].str.replace(',', '').astype(float)
house['室数']=house['室数'].astype('int')
house['厅数']=house['厅数'].astype('int')
house['楼层'] = house['楼层'].str[:4]


# In[11]:


print(house.dtypes)


# In[12]:


print(house)


# In[13]:


#  描述统计
des=house.describe().round(2)
print(des)


# In[14]:


#  相关分析
house_corr=house.corr()
print(house_corr)


# In[15]:


#  可视化
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
#  常州市二手房总价直方图
plt.rcParams['font.family'] = ['sans-serif']
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.figure(figsize=(10,6))
plt.title("常州市二手房总价直方图")
sns.distplot(house['总价（万元）'], color="royalblue",bins=50, kde=False, hist_kws={"edgecolor":"w"})
plt.xlabel("\n总价(万元)")
plt.ylabel("频\n数", rotation = 'horizontal', verticalalignment = 'center', horizontalalignment = 'right')
plt.xlim(0,1500)  # 总价最大值为1410万元，故此处设置总价区间为0-1500万元
plt.show()
plt.figure(figsize=(10,6))
#  常州市二手房单位价格直方图
plt.title("常州市二手房单位价格直方图")
sns.distplot(house['单位价格（元/㎡）'], color="royalblue",bins=20, kde=True, hist_kws={"edgecolor":"w"})
plt.xlabel("\n单位价格（元/㎡）")
plt.ylabel("频\n数", rotation = 'horizontal', verticalalignment = 'center', horizontalalignment = 'right')
yticks_list = ['0', '100', '200', '300', '400']
plt.yticks(np.arange(0.0, 0.00010, 0.00002), yticks_list)
plt.xlim(0,65000) # 总价最大值为61920万元，故此处设置总价区间为0-65000万元
plt.show()


# In[16]:


#  常州市二手房户型统计图
huxingName = list(house['户型'].value_counts().index)
huxingCountList = list(house['户型'].value_counts())
# 户型数量较少的合并为其他户型
otherCount = sum(huxingCountList[12:])
huxingName = huxingName[:12]
huxingCountList = huxingCountList[:12]
huxingName.append("其他户型")
huxingCountList.append(otherCount)

plt.figure(figsize=(10,6))
plt.title("常州市二手房户型统计图")
g = sns.barplot(huxingName, huxingCountList, alpha=0.8, color="royalblue",edgecolor="k",hatch="..")
plt.xlabel("\n户型")
plt.ylabel("计\n数", rotation = 'horizontal', verticalalignment = 'center', horizontalalignment = 'right')
for a,b in zip(range(len(huxingName)),huxingCountList):   #柱子上的数字显示
    plt.text(a,b+3,'%.f' % b,ha='center',va='bottom',fontsize=10);
plt.xticks(rotation = 45)
plt.show()


# In[17]:


#  常州市二手房建筑面积直方图
plt.figure(figsize=(10,6))
plt.title("常州市二手房建筑面积直方图")
sns.distplot(house['面积（㎡）'], color="royalblue",bins=25, kde=False, hist_kws={"edgecolor":"w"})
plt.xlabel("\n房屋面积（㎡）")
plt.ylabel("频\n数", rotation = 'horizontal', verticalalignment = 'center', horizontalalignment = 'right')
plt.xlim(0,600) # 面积最大值为575m²，故此处设置总价区间为0-600万元
plt.show()


# In[18]:


#  常州市二手房面积-单位价格散点图
plt.figure(figsize=(10,6))
plt.title("常州市二手房面积-单位价格散点图")
plt.scatter(house['面积（㎡）'], house['单位价格（元/㎡）'],color="royalblue")
plt.xlabel("\n房屋面积（㎡）")
plt.ylabel("单位价格\n（元/㎡）", rotation = 'horizontal', verticalalignment = 'center', horizontalalignment = 'right')
plt.show()


# In[19]:


#  常州市市二手房所在楼层饼状图
plt.figure(figsize=(12,10))
plt.title("常州市市二手房所在楼层饼状图")
louceng2 = house['楼层'].value_counts()
plt.pie(louceng2, labels = louceng2.index, autopct='%.2f%%', # 设置百分比的格式，这里保留一位小数
        pctdistance=0.8,  # 设置百分比标签与圆心的距离
        labeldistance = 1.1, # 设置教育水平标签与圆心的距离
        startangle = 180, # 设置饼图的初始角度
        counterclock = False, # 是否逆时针，这里设置为顺时针方向
        wedgeprops = {'linewidth': 1.5, 'edgecolor':'w'},# 设置饼图内外边界的属性值
        textprops = {'fontsize':12, 'color':'black'}, # 设置文本标签的属性值
       )
plt.show()


# In[20]:


#  总价回归分析
import statsmodels.api as sm
sample1 = house[['室数','厅数','面积（㎡）','总价（万元）']].dropna()
y1 = sample1[['总价（万元）']]
x1 = sample1[['室数','厅数','面积（㎡）']]
x10 = sm.add_constant(x1)
# ols模型 y = ax + x，其中xe是常数项
est1 = sm.OLS(y1, x10) .fit()
est1 . summary()


# In[22]:


import statsmodels.api as sm
sample2 = house[['室数','厅数','面积（㎡）','单位价格（元/㎡）']].dropna()
y2 = sample2[['单位价格（元/㎡）']]
x2 = sample2[['室数','厅数','面积（㎡）']]
x20 = sm.add_constant(x2)
# ols模型 y = ax + x，其中xe是常数项
est2 = sm.OLS(y2, x20) .fit()
est2 . summary()


# In[ ]:




